﻿

namespace TravelAgency.DataProcessor.ExportDtos
{
    public class ExportBookingDto
    {
        public string TourPackageName { get; set; }
        public string Date { get; set; }
    }
}
