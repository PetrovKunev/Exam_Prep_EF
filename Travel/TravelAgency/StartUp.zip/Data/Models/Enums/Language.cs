﻿
namespace TravelAgency.Data.Models.Enums
{
    public enum Language
    {
        English = 0,
        German = 1,
        French = 2,
        Spanish = 3,
        Russian = 4
    }
}
