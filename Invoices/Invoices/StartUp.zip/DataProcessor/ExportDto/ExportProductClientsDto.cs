﻿namespace Invoices.DataProcessor.ExportDto
{
    public class ExportProductClientsDto
    {
        public string Name { get; set; } = null!;

        public string NumberVat { get; set; } = null!;
    }
}
