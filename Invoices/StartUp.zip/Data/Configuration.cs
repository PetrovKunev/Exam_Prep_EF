﻿namespace Invoices.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=MENTAT\SQLEXPRESS;Database=Invoices2024;Integrated Security=True;Encrypt=False";
    }
}
